# Déploiement sur LWS

Ce dossier contient tous les fichiers nécessaires pour déployer l'application sur l'hébergeur LWS.

## Instructions

1. Transférez tous ces fichiers vers votre hébergement LWS via FTP ou SSH
2. Connectez-vous à votre serveur via SSH
3. Exécutez la commande: npm install --production
4. Démarrez l'application avec: npm start

Pour plus de détails, consultez le fichier DEPLOYMENT.md dans le répertoire principal du projet.
